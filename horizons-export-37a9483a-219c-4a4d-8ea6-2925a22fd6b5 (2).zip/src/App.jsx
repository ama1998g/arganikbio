import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HomePage from '@/pages/HomePage';
import ProductsPage from '@/pages/ProductsPage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import CartPage from '@/pages/CartPage';
import CheckoutPage from '@/pages/CheckoutPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import AdminLayout from '@/components/admin/AdminLayout';
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage';
import AdminProductsPage from '@/pages/admin/AdminProductsPage';
import AdminProductFormPage from '@/pages/admin/AdminProductFormPage';
import AdminOrdersPage from '@/pages/admin/AdminOrdersPage';
import AdminLoginPage from '@/pages/admin/AdminLoginPage';
import { AuthProvider } from '@/contexts/AuthContext';
import AdminSettingsPage from '@/pages/admin/AdminSettingsPage';
import AdminContentPage from '@/pages/admin/AdminContentPage';

const AppContent = () => {
  const location = useLocation();
  const showHeaderFooter = !location.pathname.startsWith('/admin');

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Arganik Bio - متجر العسل الطبيعي الأصيل</title>
        <meta name="description" content="اكتشف أجود أنواع العسل الطبيعي والمنتجات العضوية في متجر أرجانيك بايو. عسل أصيل 100% من أفضل المناحل المغربية." />
        <meta name="keywords" content="عسل طبيعي, عسل مغربي, منتجات عضوية, عسل حر, عسل جبلي, عسل سدر, متجر عسل" />
        <meta property="og:title" content="Arganik Bio - متجر العسل الطبيعي الأصيل" />
        <meta property="og:description" content="اكتشف أجود أنواع العسل الطبيعي والمنتجات العضوية في متجر أرجانيك بايو" />
        <meta property="og:type" content="website" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
      </Helmet>
      
      {showHeaderFooter && <Header />}
      
      <main className="flex-1">
        <Routes>
          {/* Frontend Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />

          {/* Admin Routes */}
          <Route path="/login" element={<Navigate to="/admin/login" replace />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboardPage />} />
            <Route path="products" element={<AdminProductsPage />} />
            <Route path="products/add" element={<AdminProductFormPage />} />
            <Route path="products/edit/:id" element={<AdminProductFormPage />} />
            <Route path="orders" element={<AdminOrdersPage />} />
            <Route path="content" element={<AdminContentPage />} />
            <Route path="settings" element={<AdminSettingsPage />} />
          </Route>
        </Routes>
      </main>
      
      {showHeaderFooter && <Footer />}
      <Toaster />
    </div>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;
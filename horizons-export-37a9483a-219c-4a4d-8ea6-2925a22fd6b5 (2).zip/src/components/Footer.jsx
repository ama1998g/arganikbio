import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Milk as Honey, Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react';
const Footer = () => {
  return <footer className="relative mt-20">
      <div className="footer-wave"></div>
      
      <div className="honey-gradient text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} className="space-y-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                  <Honey className="w-6 h-6 text-amber-600" />
                </div>
                <div className="arabic-text">
                  <span className="text-xl font-bold">Arganik Bio</span>
                  <p className="text-sm opacity-90">العسل الطبيعي الأصيل</p>
                </div>
              </div>
              <p className="arabic-text text-sm opacity-90 leading-relaxed">
                نحن نقدم أجود أنواع العسل الطبيعي والمنتجات العضوية من أفضل المناحل المحلية. 
                جودة عالية وطعم أصيل يميز منتجاتنا.
              </p>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.1
          }} className="space-y-4">
              <span className="text-lg font-semibold arabic-text">روابط سريعة</span>
              <div className="space-y-2">
                {[{
                name: 'الرئيسية',
                path: '/'
              }, {
                name: 'المنتجات',
                path: '/products'
              }, {
                name: 'من نحن',
                path: '/about'
              }, {
                name: 'اتصل بنا',
                path: '/contact'
              }].map(link => <Link key={link.path} to={link.path} className="block arabic-text text-sm opacity-90 hover:opacity-100 transition-opacity duration-300">
                    {link.name}
                  </Link>)}
              </div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} className="space-y-4">
              <span className="text-lg font-semibold arabic-text">تواصل معنا</span>
              <div className="space-y-3">
                <a href="https://wa.me/212762871219" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-3 space-x-reverse hover:opacity-80 transition-opacity">
                  <Phone className="w-4 h-4" />
                  <span className="text-sm" style={{
                  direction: 'ltr'
                }}>+212 762 871 219</span>
                </a>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">info@arganikbio.shop</span>
                </div>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm arabic-text">أكادير، المغرب</span>
                </div>
              </div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.3
          }} className="space-y-4">
              <span className="text-lg font-semibold arabic-text">تابعنا</span>
              <div className="flex space-x-4 space-x-reverse">
                {[{
                icon: Facebook,
                href: 'https://www.facebook.com/profile.php?id=61550537223381'
              }, {
                icon: Instagram,
                href: 'https://www.instagram.com/lm3alam_dipani?igsh=MTVvaWZsa3QwNTRpeA=='
              }].map((social, index) => <motion.a key={index} href={social.href} target="_blank" rel="noopener noreferrer" whileHover={{
                scale: 1.1
              }} whileTap={{
                scale: 0.95
              }} className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-300">
                    <social.icon className="w-5 h-5" />
                  </motion.a>)}
              </div>
              <p className="text-sm opacity-90 arabic-text">
                اشترك في نشرتنا الإخبارية للحصول على أحدث العروض والمنتجات
              </p>
            </motion.div>
          </div>

          <div className="section-divider opacity-30"></div>

          <div className="text-center space-y-2">
            <p className="text-sm opacity-90 arabic-text">© 2025 Arganik Bio. جميع الحقوق محفوظة.</p>
            <p className="text-xs opacity-80 arabic-text">
              تم التطوير بواسطة: يونس العمراوي
            </p>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, ShoppingCart, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="product-card rounded-2xl overflow-hidden shadow-lg group"
    >
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
            <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <Eye className="w-8 h-8 text-white" />
            </div>
          </div>
          {product.badge && (
            <div className="absolute top-3 right-3 bg-amber-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
              {product.badge}
            </div>
          )}
        </div>

        <div className="p-6">
          <h3 className="text-lg font-semibold arabic-text text-amber-800 mb-2 group-hover:text-amber-600 transition-colors duration-300">
            {product.name}
          </h3>
          
          <p className="arabic-text text-gray-600 text-sm mb-3 line-clamp-2">
            {product.description}
          </p>

          <div className="flex items-center mb-3">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < product.rating 
                      ? 'text-yellow-400 fill-current' 
                      : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <span className="text-gray-500 text-sm mr-2">
              ({product.reviews})
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="price-tag text-lg">
              {product.price} درهم
            </div>
            
            <Button
              onClick={handleAddToCart}
              className="btn-primary px-4 py-2 text-sm arabic-text"
            >
              <ShoppingCart className="w-4 h-4 ml-1" />
              أضف للسلة
            </Button>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default ProductCard;
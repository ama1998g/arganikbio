import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, Package, ShoppingCart, Home, LogOut, Settings, FileText } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';

const navItems = [
  { name: 'لوحة التحكم', path: '/admin', icon: LayoutDashboard },
  { name: 'المنتجات', path: '/admin/products', icon: Package },
  { name: 'الطلبات', path: '/admin/orders', icon: ShoppingCart },
  { name: 'إدارة المحتوى', path: '/admin/content', icon: FileText },
  { name: 'الإعدادات', path: '/admin/settings', icon: Settings },
];

const AdminSidebar = () => {
  const location = useLocation();
  const { logout } = useAuth();

  return (
    <aside className="admin-sidebar">
      <div className="flex flex-col h-full">
        <div className="text-center mb-10">
          <h1 className="text-2xl font-bold text-amber-800">لوحة تحكم Arganik</h1>
        </div>
        <nav className="flex-1">
          <ul>
            {navItems.map((item) => (
              <li key={item.path}>
                <Link to={item.path}>
                  <motion.div
                    whileHover={{ x: -5 }}
                    className={`flex items-center p-3 my-2 rounded-lg transition-colors duration-200 ${
                      location.pathname === item.path || (item.path !== '/admin' && location.pathname.startsWith(item.path))
                        ? 'bg-amber-500 text-white shadow-md'
                        : 'text-gray-600 hover:bg-amber-100'
                    }`}
                  >
                    <item.icon className="w-5 h-5 ml-3" />
                    <span className="font-medium">{item.name}</span>
                  </motion.div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="mt-auto space-y-2">
           <Link to="/">
              <motion.div
                whileHover={{ x: -5 }}
                className="flex items-center p-3 rounded-lg transition-colors duration-200 text-gray-600 hover:bg-amber-100"
              >
                <Home className="w-5 h-5 ml-3" />
                <span className="font-medium">العودة للمتجر</span>
              </motion.div>
            </Link>
            <Button
              onClick={logout}
              variant="ghost"
              className="w-full justify-start text-gray-600 hover:bg-red-100 hover:text-red-600"
            >
              <LogOut className="w-5 h-5 ml-3" />
              <span className="font-medium">تسجيل الخروج</span>
            </Button>
        </div>
      </div>
    </aside>
  );
};

export default AdminSidebar;
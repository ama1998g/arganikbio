import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const ContentContext = createContext();

export const useContent = () => useContext(ContentContext);

export const ContentProvider = ({ children }) => {
  const [content, setContent] = useState({});
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchContent = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('site_content').select('*');

    if (error) {
      console.error('Error fetching site content:', error);
      toast({
        title: 'خطأ في تحميل المحتوى',
        description: 'حدث خطأ أثناء جلب محتوى الموقع.',
        variant: 'destructive',
      });
    } else {
      const contentMap = data.reduce((acc, item) => {
        acc[item.content_key] = item.content_value;
        return acc;
      }, {});
      setContent(contentMap);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchContent();
  }, [fetchContent]);

  const updateContent = async (key, value) => {
    const { error } = await supabase
      .from('site_content')
      .update({ content_value: value })
      .eq('content_key', key);

    if (error) {
      console.error('Error updating content:', error);
      toast({
        title: 'خطأ في تحديث المحتوى',
        variant: 'destructive',
      });
      return false;
    } else {
      await fetchContent();
      return true;
    }
  };

  const value = { content, loading, updateContent, refetchContent: fetchContent };

  return (
    <ContentContext.Provider value={value}>
      {children}
    </ContentContext.Provider>
  );
};
import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { products as initialProducts } from '@/data/products';
import { toast } from '@/components/ui/use-toast';

const ProductContext = createContext();

const productReducer = (state, action) => {
  switch (action.type) {
    case 'SET_PRODUCTS':
      return action.payload;
    case 'ADD_PRODUCT':
      return [...state, action.payload];
    case 'UPDATE_PRODUCT':
      return state.map(product =>
        product.id === action.payload.id ? action.payload : product
      );
    case 'DELETE_PRODUCT':
      return state.filter(product => product.id !== action.payload);
    default:
      return state;
  }
};

export const ProductProvider = ({ children }) => {
  const [products, dispatch] = useReducer(productReducer, []);

  const fetchProducts = useCallback(async () => {
    const { data: productsData, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "خطأ في تحميل المنتجات",
        description: "حدث خطأ أثناء جلب المنتجات من قاعدة البيانات.",
        variant: "destructive",
      });
    } else if (productsData.length === 0) {
      const productsToSeed = initialProducts.map(({ id, ...rest }) => rest);
      const { error: seedError } = await supabase.from('products').insert(productsToSeed);
      if (seedError) {
        console.error('Error seeding products:', seedError);
      } else {
        fetchProducts();
      }
    } else {
      dispatch({ type: 'SET_PRODUCTS', payload: productsData });
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const addProduct = async (product) => {
    const { data, error } = await supabase
      .from('products')
      .insert([product])
      .select();

    if (error) {
      console.error('Error adding product:', error);
      toast({
        title: "خطأ في إضافة المنتج",
        variant: "destructive",
      });
    } else {
      dispatch({ type: 'ADD_PRODUCT', payload: data[0] });
      toast({
        title: "تمت الإضافة بنجاح",
        description: `تمت إضافة المنتج ${product.name}.`,
      });
    }
  };

  const updateProduct = async (product) => {
    const { id, ...productToUpdate } = product;
    const { data, error } = await supabase
      .from('products')
      .update(productToUpdate)
      .eq('id', id)
      .select();

    if (error) {
      console.error('Error updating product:', error);
      toast({
        title: "خطأ في تحديث المنتج",
        variant: "destructive",
      });
    } else {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data[0] });
      toast({
        title: "تم التحديث بنجاح",
        description: `تم تحديث المنتج ${product.name}.`,
      });
    }
  };

  const deleteProduct = async (productId) => {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', productId);

    if (error) {
      console.error('Error deleting product:', error);
      toast({
        title: "خطأ في حذف المنتج",
        variant: "destructive",
      });
    } else {
      dispatch({ type: 'DELETE_PRODUCT', payload: productId });
      toast({
        title: "تم الحذف بنجاح",
        description: `تم حذف المنتج.`,
        variant: "destructive",
      });
    }
  };
  
  const getProductById = (id) => {
    const productId = parseInt(id, 10);
    return products.find(p => p.id === productId);
  };

  return (
    <ProductContext.Provider value={{ products, addProduct, updateProduct, deleteProduct, getProductById }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};
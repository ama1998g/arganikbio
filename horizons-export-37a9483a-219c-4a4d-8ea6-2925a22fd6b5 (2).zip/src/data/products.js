export const products = [
  {
    id: 1,
    name: 'عسل السدر الجبلي',
    description: 'عسل السدر الجبلي الأصيل من أشجار السدر البرية في جبال الأطلس. يتميز بطعمه الفريد وفوائده الصحية العديدة.',
    price: 350,
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop',
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=400&h=300&fit=crop',
      'https://images.unsplash.com/photo-1516824711773-7ad4b6b5b6e1?w=400&h=300&fit=crop'
    ],
    category: 'sidr',
    rating: 5,
    reviews: 45,
    stock: 25,
    badge: 'الأكثر مبيعاً',
    features: [
      'عسل طبيعي 100% من أشجار السدر',
      'غني بالفيتامينات والمعادن',
      'يساعد في تقوية المناعة',
      'مفيد للجهاز الهضمي',
      'خالمن أي مواد حافظة أو إضافات'
    ],
    weight: '500 جرام',
    origin: 'جبال الأطلس - المغرب',
    productionDate: '2024',
    shelfLife: 'سنتان'
  },
  {
    id: 2,
    name: 'عسل الزهور البرية',
    description: 'عسل طبيعي من رحيق الزهور البرية المتنوعة في سهول المغرب. يتميز بنكهة متوازنة ولون ذهبي جميل.',
    price: 180,
    image: 'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=400&h=300&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=400&h=300&fit=crop',
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop'
    ],
    category: 'wildflower',
    rating: 4,
    reviews: 32,
    stock: 40,
    features: [
      'من رحيق الزهور البرية المتنوعة',
      'طعم متوازن ولذيذ',
      'غني بمضادات الأكسدة',
      'مناسب للاستخدام اليومي',
      'معبأ بطريقة صحية وآمنة'
    ],
     origin: 'سهول المغرب'
  },
  {
    id: 3,
    name: 'عسل الأكاسيا الأبيض',
    description: 'عسل الأكاسيا الفاخر بلونه الذهبي الفاتح وطعمه الرقيق. مثالي للأطفال وكبار السن.',
    price: 220,
    image: 'https://images.unsplash.com/photo-1516824711773-7ad4b6b5b6e1?w=400&h=300&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1516824711773-7ad4b6b5b6e1?w=400&h=300&fit=crop',
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=400&h=300&fit=crop'
    ],
    category: 'acacia',
    rating: 5,
    reviews: 28,
    stock: 30,
    badge: 'جديد',
    features: [
      'عسل أكاسيا أصيل',
      'طعم رقيق ومناسب للجميع',
      'لون ذهبي فاتح مميز',
      'سهل الهضم',
      'مناسب للأطفال'
    ],
     origin: 'شمال المغرب'
  },
  {
    id: 4,
    name: 'عسل الليمون',
    description: 'عسل طبيعي من أزهار الليمون بنكهة منعشة ورائحة عطرة مميزة من بساتين سوس.',
    price: 200,
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop'
    ],
    category: 'wildflower',
    rating: 4,
    reviews: 19,
    stock: 35,
    features: [
      'من أزهار الليمون الطبيعية',
      'نكهة منعشة ومميزة',
      'غني بفيتامين C',
      'مفيد للجهاز التنفسي',
      'رائحة عطرة جذابة'
    ],
    origin: 'منطقة سوس - المغرب'
  }
];
import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Award, Users, Leaf, Heart } from 'lucide-react';

const AboutPage = () => {
  const values = [
    {
      icon: Leaf,
      title: 'طبيعي 100%',
      description: 'نحن ملتزمون بتقديم منتجات طبيعية خالية من أي مواد صناعية أو مضافات كيميائية'
    },
    {
      icon: Award,
      title: 'جودة عالية',
      description: 'نحرص على أعلى معايير الجودة في جميع مراحل الإنتاج والتعبئة والتوزيع'
    },
    {
      icon: Users,
      title: 'ثقة العملاء',
      description: 'نبني علاقات طويلة الأمد مع عملائنا من خلال الشفافية والصدق في التعامل'
    },
    {
      icon: Heart,
      title: 'الصحة والعافية',
      description: 'هدفنا هو تعزيز صحة وعافية عملائنا من خلال منتجات طبيعية مفيدة'
    }
  ];

  const team = [
    {
      name: 'Brahim Takoucht',
      role: 'المؤسس والمدير التنفيذي',
      image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/37a9483a-219c-4a4d-8ea6-2925a22fd6b5/06e8a9630ac5513e915d33c5e7a4817f.jpg',
      description: 'مؤسس Arganik Bio، شغوف بالطبيعة وإنتاج العسل الأصيل من قلب سوس.'
    },
    {
      name: 'فاطمة علي',
      role: 'مديرة الجودة',
      image: null,
      description: 'متخصصة في ضمان الجودة والمعايير الصحية'
    },
    {
      name: 'محمد السعيد',
      role: 'مدير المبيعات',
      image: null,
      description: 'خبير في خدمة العملاء وتطوير الأعمال'
    }
  ];

  return (
    <>
      <Helmet>
        <title>من نحن - Arganik Bio</title>
        <meta name="description" content="تعرف على قصة أرجانيك بايو ورؤيتنا في تقديم أجود أنواع العسل الطبيعي والمنتجات العضوية" />
      </Helmet>

      <div className="pt-24 pb-12">
        <section className="hero-bg py-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center max-w-4xl mx-auto"
            >
              <h1 className="text-4xl lg:text-5xl font-bold arabic-text text-amber-800 mb-6">
                من نحن
              </h1>
              <p className="text-xl arabic-text text-gray-700 leading-relaxed">
                نحن في أرجانيك بايو نؤمن بقوة الطبيعة وفوائدها العظيمة. منذ تأسيسنا، 
                نسعى لتقديم أجود أنواع العسل الطبيعي والمنتجات العضوية التي تعزز صحة وعافية عملائنا.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                <h2 className="text-3xl font-bold arabic-text text-amber-800">
                  قصتنا
                </h2>
                <p className="arabic-text text-gray-700 leading-relaxed text-lg">
                  بدأت رحلتنا، بقيادة مؤسسنا إبراهيم تاكوشت، من حب عميق للطبيعة والرغبة في تقديم منتجات طبيعية أصيلة من قلب مدينة أكادير. 
                  نعمل مع أفضل النحالين المحليين الذين يتبعون أساليب تربية النحل التقليدية 
                  والمستدامة.
                </p>
                <p className="arabic-text text-gray-700 leading-relaxed text-lg">
                  نحن نؤمن أن العسل الطبيعي ليس مجرد طعام، بل هو دواء وغذاء ومصدر للطاقة 
                  والحيوية. لذلك نحرص على أن تصل منتجاتنا إليكم بأعلى جودة ممكنة.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="relative"
              >
                <img  
                  alt="نحال يعمل مع خلايا النحل في المنحل"
                  className="w-full h-auto rounded-2xl shadow-xl"
                 src="https://images.unsplash.com/photo-1698610641110-ca0fe9cac9e0" />
                <div className="absolute -bottom-6 -left-6 w-24 h-24 honey-gradient rounded-full opacity-20 floating-animation"></div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 honey-pattern">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl font-bold arabic-text text-amber-800 mb-4">
                قيمنا ومبادئنا
              </h2>
              <p className="text-xl arabic-text text-gray-600 max-w-2xl mx-auto">
                نحن نؤمن بمجموعة من القيم التي توجه عملنا وتحدد هويتنا
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="glass-effect rounded-2xl p-6 text-center hover:shadow-xl transition-all duration-300"
                >
                  <div className="w-16 h-16 honey-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold arabic-text text-amber-800 mb-3">
                    {value.title}
                  </h3>
                  <p className="arabic-text text-gray-600 text-sm leading-relaxed">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl font-bold arabic-text text-amber-800 mb-4">
                فريق العمل
              </h2>
              <p className="text-xl arabic-text text-gray-600 max-w-2xl mx-auto">
                تعرف على الفريق المتخصص الذي يعمل بجد لتقديم أفضل المنتجات
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {team.map((member, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="glass-effect rounded-2xl p-6 text-center"
                >
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden border-4 border-amber-200 shadow-lg">
                    {member.image ? (
                      <img src={member.image} alt={member.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full honey-gradient flex items-center justify-center">
                        <Users className="w-12 h-12 text-white" />
                      </div>
                    )}
                  </div>
                  <h3 className="text-xl font-semibold arabic-text text-amber-800 mb-2">
                    {member.name}
                  </h3>
                  <p className="text-amber-600 arabic-text font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="arabic-text text-gray-600 text-sm leading-relaxed">
                    {member.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 honey-gradient text-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                <h2 className="text-3xl font-bold arabic-text">
                  رسالتنا
                </h2>
                <p className="arabic-text text-lg leading-relaxed opacity-90">
                  نسعى لتقديم أجود أنواع العسل الطبيعي والمنتجات العضوية التي تعزز 
                  صحة وعافية عملائنا، مع الحفاظ على البيئة ودعم المجتمعات المحلية.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="space-y-6"
              >
                <h2 className="text-3xl font-bold arabic-text">
                  رؤيتنا
                </h2>
                <p className="arabic-text text-lg leading-relaxed opacity-90">
                  أن نكون الخيار الأول للعملاء الباحثين عن المنتجات الطبيعية عالية الجودة، 
                  وأن نساهم في نشر ثقافة الغذاء الصحي والطبيعي في مجتمعنا.
                </p>
              </motion.div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default AboutPage;
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ShoppingCart, Plus, Minus, Trash2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';

const CartPage = () => {
  const { cart, updateQuantity, removeFromCart, getTotalPrice, clearCart } = useCart();

  if (cart.items.length === 0) {
    return (
      <>
        <Helmet>
          <title>سلة التسوق - Arganik Bio</title>
          <meta name="description" content="سلة التسوق الخاصة بك في متجر أرجانيك بايو للعسل الطبيعي" />
        </Helmet>

        <div className="pt-24 pb-12">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <div className="w-32 h-32 mx-auto mb-8 opacity-20">
                <ShoppingCart className="w-full h-full text-gray-400" />
              </div>
              <h1 className="text-3xl font-bold arabic-text text-gray-600 mb-4">
                سلة التسوق خاوية
              </h1>
              <p className="arabic-text text-gray-500 mb-8">
                مازال ما ضفتي حتى منتوج للسلة ديالك
              </p>
              <Link to="/products">
                <Button className="btn-primary text-lg px-8 py-3 arabic-text">
                  تسوق دابا
                  <ArrowLeft className="mr-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>سلة التسوق - Arganik Bio</title>
        <meta name="description" content="سلة التسوق الخاصة بك في متجر أرجانيك بايو للعسل الطبيعي" />
      </Helmet>

      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl font-bold arabic-text text-amber-800 mb-2">
              سلة التسوق
            </h1>
            <p className="arabic-text text-gray-600">
              عندك {cart.items.length} منتوج فالسلة
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cart.items.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="cart-item"
                >
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-semibold arabic-text text-amber-800 truncate">
                        {item.name}
                      </h3>
                      <p className="text-sm arabic-text text-gray-600 mb-2">
                        {item.price} درهم للحبة
                      </p>
                      
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 rounded-full honey-gradient text-white flex items-center justify-center hover:shadow-lg transition-all duration-300"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-12 text-center font-semibold">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 rounded-full honey-gradient text-white flex items-center justify-center hover:shadow-lg transition-all duration-300"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="price-tag">
                        {(item.price * item.quantity).toFixed(2)} درهم
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="flex justify-between items-center pt-4"
              >
                <Button
                  onClick={clearCart}
                  variant="outline"
                  className="arabic-text text-red-600 border-red-600 hover:bg-red-50"
                >
                  مسح السلة
                </Button>
                
                <Link to="/products">
                  <Button variant="outline" className="arabic-text">
                    كمل التسوق
                  </Button>
                </Link>
              </motion.div>
            </div>

            {/* Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-1"
            >
              <div className="glass-effect rounded-2xl p-6 sticky top-24">
                <h2 className="text-xl font-bold arabic-text text-amber-800 mb-6">
                  ملخص الطلب
                </h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between arabic-text">
                    <span>المجموع:</span>
                    <span>{getTotalPrice().toFixed(2)} درهم</span>
                  </div>
                  <div className="flex justify-between arabic-text">
                    <span>التوصيل:</span>
                    <span className="text-green-600">مجاني</span>
                  </div>
                  <div className="section-divider"></div>
                  <div className="flex justify-between text-lg font-bold arabic-text">
                    <span>المجموع الكلي:</span>
                    <span className="text-amber-600">{getTotalPrice().toFixed(2)} درهم</span>
                  </div>
                </div>

                <Link to="/checkout" className="block">
                  <Button className="btn-primary w-full text-lg py-3 arabic-text">
                    إتمام الطلب
                    <ArrowLeft className="mr-2 h-5 w-5" />
                  </Button>
                </Link>

                <div className="mt-6 p-4 bg-amber-50 rounded-lg">
                  <p className="text-sm arabic-text text-amber-800 text-center">
                    🚚 توصيل مجاني لجميع أنحاء المغرب
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CartPage;
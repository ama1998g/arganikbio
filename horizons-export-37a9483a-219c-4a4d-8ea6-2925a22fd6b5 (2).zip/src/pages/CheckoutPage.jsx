import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { CreditCard, Truck, Shield, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { toast } from '@/components/ui/use-toast';

const CheckoutPage = () => {
  const { cart, getTotalPrice, clearCart } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    paymentMethod: 'card'
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate order processing
    setTimeout(() => {
      setIsProcessing(false);
      setOrderComplete(true);
      clearCart();
      toast({
        title: "تم إتمام الطلب بنجاح!",
        description: "سيتم التواصل معك قريباً لتأكيد الطلب",
        duration: 5000
      });
    }, 2000);
  };

  if (cart.items.length === 0 && !orderComplete) {
    return (
      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-2xl font-bold arabic-text text-gray-600 mb-4">
            سلة التسوق فارغة
          </h1>
          <p className="arabic-text text-gray-500 mb-8">
            لا يمكن إتمام الطلب بدون منتجات في السلة
          </p>
        </div>
      </div>
    );
  }

  if (orderComplete) {
    return (
      <>
        <Helmet>
          <title>تم إتمام الطلب - Arganik Bio</title>
        </Helmet>

        <div className="pt-24 pb-12">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto text-center success-animation"
            >
              <div className="w-24 h-24 mx-auto mb-6 honey-gradient rounded-full flex items-center justify-center">
                <CheckCircle className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-3xl font-bold arabic-text text-amber-800 mb-4">
                تم إتمام الطلب بنجاح!
              </h1>
              <p className="arabic-text text-gray-600 mb-8">
                شكراً لك على طلبك. سيتم التواصل معك قريباً لتأكيد الطلب وترتيب التوصيل.
              </p>
              <div className="glass-effect rounded-2xl p-6 mb-8">
                <h3 className="text-lg font-semibold arabic-text text-amber-800 mb-4">
                  رقم الطلب: #ARG{Date.now().toString().slice(-6)}
                </h3>
                <p className="text-sm arabic-text text-gray-600">
                  احتفظ برقم الطلب للمراجعة
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>إتمام الطلب - Arganik Bio</title>
        <meta name="description" content="أتمم طلبك من متجر أرجانيك بايو للعسل الطبيعي" />
      </Helmet>

      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl font-bold arabic-text text-amber-800 mb-2">
              إتمام الطلب
            </h1>
            <p className="arabic-text text-gray-600">
              أكمل بياناتك لإتمام عملية الشراء
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Checkout Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Personal Information */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="checkout-form"
                >
                  <h2 className="text-xl font-bold arabic-text text-amber-800 mb-6">
                    المعلومات الشخصية
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        الاسم الأول *
                      </label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="أدخل الاسم الأول"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        الاسم الأخير *
                      </label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="أدخل الاسم الأخير"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        البريد الإلكتروني *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="example@email.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        رقم الهاتف *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="+966 50 123 4567"
                      />
                    </div>
                  </div>
                </motion.div>

                {/* Shipping Address */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="checkout-form"
                >
                  <h2 className="text-xl font-bold arabic-text text-amber-800 mb-6">
                    عنوان التوصيل
                  </h2>
                  
                  <div>
                    <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                      العنوان التفصيلي *
                    </label>
                    <textarea
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      required
                      rows="3"
                      className="form-input"
                      placeholder="أدخل العنوان التفصيلي..."
                    ></textarea>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        المدينة *
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="الرياض"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        الرمز البريدي
                      </label>
                      <input
                        type="text"
                        name="postalCode"
                        value={formData.postalCode}
                        onChange={handleInputChange}
                        className="form-input"
                        placeholder="12345"
                      />
                    </div>
                  </div>
                </motion.div>

                {/* Payment Method */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="checkout-form"
                >
                  <h2 className="text-xl font-bold arabic-text text-amber-800 mb-6">
                    طريقة الدفع
                  </h2>
                  
                  <div className="space-y-4">
                    <label className="flex items-center space-x-3 space-x-reverse p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-amber-300 transition-colors duration-300">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="card"
                        checked={formData.paymentMethod === 'card'}
                        onChange={handleInputChange}
                        className="text-amber-600"
                      />
                      <CreditCard className="w-5 h-5 text-amber-600" />
                      <span className="arabic-text font-medium">بطاقة ائتمانية</span>
                    </label>
                    
                    <label className="flex items-center space-x-3 space-x-reverse p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-amber-300 transition-colors duration-300">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="cash"
                        checked={formData.paymentMethod === 'cash'}
                        onChange={handleInputChange}
                        className="text-amber-600"
                      />
                      <Truck className="w-5 h-5 text-amber-600" />
                      <span className="arabic-text font-medium">الدفع عند التوصيل</span>
                    </label>
                  </div>
                </motion.div>

                {/* Submit Button */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Button
                    type="submit"
                    disabled={isProcessing}
                    className="btn-primary w-full text-lg py-4 arabic-text"
                  >
                    {isProcessing ? (
                      <div className="flex items-center justify-center space-x-2 space-x-reverse">
                        <div className="loading-spinner"></div>
                        <span>جاري المعالجة...</span>
                      </div>
                    ) : (
                      <>
                        <Shield className="ml-2 h-5 w-5" />
                        تأكيد الطلب
                      </>
                    )}
                  </Button>
                </motion.div>
              </form>
            </div>

            {/* Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-1"
            >
              <div className="glass-effect rounded-2xl p-6 sticky top-24">
                <h2 className="text-xl font-bold arabic-text text-amber-800 mb-6">
                  ملخص الطلب
                </h2>

                <div className="space-y-4 mb-6">
                  {cart.items.map((item) => (
                    <div key={item.id} className="flex justify-between items-center">
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div>
                          <p className="text-sm arabic-text font-medium text-gray-800">
                            {item.name}
                          </p>
                          <p className="text-xs arabic-text text-gray-600">
                            الكمية: {item.quantity}
                          </p>
                        </div>
                      </div>
                      <span className="text-sm font-semibold">
                        {(item.price * item.quantity).toFixed(2)} ريال
                      </span>
                    </div>
                  ))}
                </div>

                <div className="section-divider"></div>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between arabic-text">
                    <span>المجموع الفرعي:</span>
                    <span>{getTotalPrice().toFixed(2)} ريال</span>
                  </div>
                  <div className="flex justify-between arabic-text">
                    <span>الشحن:</span>
                    <span className="text-green-600">مجاني</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold arabic-text">
                    <span>المجموع الكلي:</span>
                    <span className="text-amber-600">{getTotalPrice().toFixed(2)} ريال</span>
                  </div>
                </div>

                <div className="p-4 bg-amber-50 rounded-lg">
                  <div className="flex items-center space-x-2 space-x-reverse mb-2">
                    <Shield className="w-4 h-4 text-amber-600" />
                    <span className="text-sm arabic-text font-medium text-amber-800">
                      دفع آمن ومضمون
                    </span>
                  </div>
                  <p className="text-xs arabic-text text-amber-700">
                    جميع المعاملات محمية بأعلى معايير الأمان
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CheckoutPage;
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "تم إرسال رسالتك بنجاح!",
      description: "سنتواصل معك قريباً",
      duration: 5000
    });
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'الهاتف',
      details: ['+966 50 123 4567', '+966 11 234 5678'],
      description: 'متاح 24/7 لخدمتكم'
    },
    {
      icon: Mail,
      title: 'البريد الإلكتروني',
      details: ['info@arganikbio.com', 'support@arganikbio.com'],
      description: 'نرد خلال 24 ساعة'
    },
    {
      icon: MapPin,
      title: 'العنوان',
      details: ['الرياض، المملكة العربية السعودية'],
      description: 'مقر الشركة الرئيسي'
    },
    {
      icon: Clock,
      title: 'ساعات العمل',
      details: ['السبت - الخميس: 8:00 ص - 6:00 م', 'الجمعة: مغلق'],
      description: 'أوقات العمل الرسمية'
    }
  ];

  return (
    <>
      <Helmet>
        <title>اتصل بنا - Arganik Bio</title>
        <meta name="description" content="تواصل مع فريق أرجانيك بايو للاستفسارات والدعم. نحن هنا لخدمتكم في أي وقت." />
      </Helmet>

      <div className="pt-24 pb-12">
        {/* Hero Section */}
        <section className="hero-bg py-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center max-w-3xl mx-auto"
            >
              <h1 className="text-4xl lg:text-5xl font-bold arabic-text text-amber-800 mb-6">
                تواصل معنا
              </h1>
              <p className="text-xl arabic-text text-gray-700 leading-relaxed">
                نحن هنا لخدمتكم والإجابة على جميع استفساراتكم. 
                لا تترددوا في التواصل معنا في أي وقت.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Contact Info Cards */}
        <section className="py-20 honey-pattern">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="glass-effect rounded-2xl p-6 text-center hover:shadow-xl transition-all duration-300"
                >
                  <div className="w-16 h-16 honey-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                    <info.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold arabic-text text-amber-800 mb-3">
                    {info.title}
                  </h3>
                  <div className="space-y-1 mb-3">
                    {info.details.map((detail, i) => (
                      <p key={i} className="arabic-text text-gray-700 text-sm">
                        {detail}
                      </p>
                    ))}
                  </div>
                  <p className="arabic-text text-gray-600 text-xs">
                    {info.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form & Map */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="checkout-form"
              >
                <h2 className="text-2xl font-bold arabic-text text-amber-800 mb-6">
                  أرسل لنا رسالة
                </h2>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        الاسم الكامل *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="أدخل اسمك الكامل"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        البريد الإلكتروني *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                        placeholder="example@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        رقم الهاتف
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="form-input"
                        placeholder="+966 50 123 4567"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                        الموضوع *
                      </label>
                      <select
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        required
                        className="form-input"
                      >
                        <option value="">اختر الموضوع</option>
                        <option value="general">استفسار عام</option>
                        <option value="order">استفسار عن طلب</option>
                        <option value="product">استفسار عن منتج</option>
                        <option value="complaint">شكوى</option>
                        <option value="suggestion">اقتراح</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium arabic-text text-gray-700 mb-2">
                      الرسالة *
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows="6"
                      className="form-input"
                      placeholder="اكتب رسالتك هنا..."
                    ></textarea>
                  </div>

                  <Button
                    type="submit"
                    className="btn-primary w-full text-lg py-3 arabic-text"
                  >
                    <Send className="ml-2 h-5 w-5" />
                    إرسال الرسالة
                  </Button>
                </form>
              </motion.div>

              {/* Map & Additional Info */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="space-y-8"
              >
                {/* Map Placeholder */}
                <div className="glass-effect rounded-2xl p-6">
                  <h3 className="text-xl font-bold arabic-text text-amber-800 mb-4">
                    موقعنا على الخريطة
                  </h3>
                  <div className="w-full h-64 bg-gradient-to-br from-amber-100 to-amber-200 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="w-12 h-12 text-amber-600 mx-auto mb-2" />
                      <p className="arabic-text text-amber-800 font-medium">
                        الرياض، المملكة العربية السعودية
                      </p>
                    </div>
                  </div>
                </div>

                {/* FAQ */}
                <div className="glass-effect rounded-2xl p-6">
                  <h3 className="text-xl font-bold arabic-text text-amber-800 mb-4">
                    أسئلة شائعة
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold arabic-text text-gray-800 mb-2">
                        كم يستغرق التوصيل؟
                      </h4>
                      <p className="arabic-text text-gray-600 text-sm">
                        نقوم بالتوصيل خلال 24-48 ساعة داخل الرياض، و3-5 أيام لباقي المناطق.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold arabic-text text-gray-800 mb-2">
                        هل يمكنني إرجاع المنتج؟
                      </h4>
                      <p className="arabic-text text-gray-600 text-sm">
                        نعم، يمكنك إرجاع المنتج خلال 7 أيام من تاريخ الاستلام.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold arabic-text text-gray-800 mb-2">
                        كيف أتأكد من جودة العسل؟
                      </h4>
                      <p className="arabic-text text-gray-600 text-sm">
                        جميع منتجاتنا مفحوصة ومعتمدة من الجهات المختصة.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ContactPage;
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Star, Shield, Truck, Award, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/ProductCard';
import { useProducts } from '@/contexts/ProductContext';

const HomePage = () => {
  const { products } = useProducts();
  const featuredProducts = products.slice(0, 3);

  const features = [
    {
      icon: Shield,
      title: 'عسل حر 100%',
      description: 'منتجاتنا طبيعية بالكامل بدون أي إضافات صناعية'
    },
    {
      icon: Award,
      title: 'جودة مضمونة',
      description: 'نضمن أعلى معايير الجودة في جميع منتجاتنا'
    },
    {
      icon: Truck,
      title: 'توصيل سريع',
      description: 'توصيل مجاني لجميع أنحاء المغرب خلال 24 ساعة'
    }
  ];

  const testimonials = [
    {
      name: 'أحمد أمين',
      rating: 5,
      comment: 'عسل رائع وبنة أصيلة، كنصح به بزاف'
    },
    {
      name: 'فاطمة الزهراء',
      rating: 5,
      comment: 'جودة ممتازة وتوصيل سريع، شكراً ليكم'
    },
    {
      name: 'يوسف العلمي',
      rating: 5,
      comment: 'أحسن عسل جربتو، غادي نكوموندي مرة أخرى بالتأكيد'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Arganik Bio - متجر العسل الطبيعي الأصيل</title>
        <meta name="description" content="اكتشف أجود أنواع العسل الطبيعي والمنتجات العضوية في متجر أرجانيك بايو. عسل حر 100% من أفضل المناحل المغربية." />
      </Helmet>

      {/* Hero Section */}
      <section className="hero-bg min-h-screen flex items-center justify-center pt-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <h1 className="hero-title text-5xl lg:text-6xl font-bold arabic-text text-amber-800 leading-tight">
                العسل الطبيعي
                <span className="block text-amber-600">الحر</span>
              </h1>
              <p className="text-xl arabic-text text-gray-700 leading-relaxed">
                اكتشف أجود أنواع العسل الطبيعي من أفضل المناحل المغربية. 
                بنة أصيلة وجودة عالية كتميز منتوجاتنا.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/products">
                  <Button className="btn-primary text-lg px-8 py-3 arabic-text">
                    تسوق الآن
                    <ArrowLeft className="mr-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline" className="text-lg px-8 py-3 arabic-text border-2 border-amber-600 text-amber-600 hover:bg-amber-50">
                    اعرف المزيد
                  </Button>
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="floating-animation">
                <img
                  alt="عسل طبيعي أصيل في برطمانات زجاجية"
                  className="w-full h-auto rounded-3xl shadow-2xl"
                 src="https://images.unsplash.com/photo-1629570896417-b5b5d8ecc955" />
              </div>
              <div className="absolute -bottom-6 -right-6 w-24 h-24 honey-gradient rounded-full pulse-glow opacity-20"></div>
              <div className="absolute -top-6 -left-6 w-16 h-16 bg-amber-200 rounded-full opacity-30 floating-animation"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 honey-pattern">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold arabic-text text-amber-800 mb-4">
              علاش تختار منتوجاتنا؟
            </h2>
            <p className="text-xl arabic-text text-gray-600 max-w-2xl mx-auto">
              كنقدمو ليك أحسن منتوجات العسل الطبيعي بأعلى معايير الجودة
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="glass-effect rounded-2xl p-8 text-center hover:shadow-xl transition-all duration-300"
              >
                <div className="w-16 h-16 honey-gradient rounded-full flex items-center justify-center mx-auto mb-6">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold arabic-text text-amber-800 mb-4">
                  {feature.title}
                </h3>
                <p className="arabic-text text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold arabic-text text-amber-800 mb-4">
              منتوجاتنا المميزة
            </h2>
            <p className="text-xl arabic-text text-gray-600 max-w-2xl mx-auto">
              اكتشف تشكيلة مختارة من أفضل أنواع العسل الحر
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>

          <div className="text-center">
            <Link to="/products">
              <Button className="btn-primary text-lg px-8 py-3 arabic-text">
                شوف جميع المنتوجات
                <ArrowLeft className="mr-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 honey-pattern">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold arabic-text text-amber-800 mb-4">
              آراء الزبناء
            </h2>
            <p className="text-xl arabic-text text-gray-600 max-w-2xl mx-auto">
              قرا تجارب الزبناء ديالنا مع منتوجاتنا الطبيعية
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="testimonial-card"
              >
                <div className="relative z-10">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="arabic-text text-gray-700 mb-4 leading-relaxed">
                    "{testimonial.comment}"
                  </p>
                  <span className="arabic-text font-semibold text-amber-800">
                    {testimonial.name}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 honey-gradient text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl font-bold arabic-text mb-6">
              بدا رحلتك مع العسل الطبيعي الحر
            </h2>
            <p className="text-xl arabic-text mb-8 opacity-90">
              انضم لآلاف الزبناء لي كايتيقو فجودة منتوجاتنا الطبيعية
            </p>
            <Link to="/products">
              <Button className="bg-white text-amber-600 hover:bg-gray-100 text-lg px-8 py-3 arabic-text font-semibold">
                تسوق الآن
                <ArrowLeft className="mr-2 h-5 w-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default HomePage;
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ArrowRight, Star, Plus, Minus, ShoppingCart, Heart, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { toast } from '@/components/ui/use-toast';
import { useProducts } from '@/contexts/ProductContext';

const ProductDetailPage = () => {
  const { id } = useParams();
  const { getProductById } = useProducts();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const product = getProductById(id);

  if (!product) {
    return (
      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-2xl font-bold arabic-text text-gray-600 mb-4">
            المنتوج غير موجود
          </h1>
          <Link to="/products">
            <Button className="btn-primary arabic-text">
              الرجوع للمنتوجات
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  const handleQuantityChange = (change) => {
    const newQuantity = quantity + change;
    if (newQuantity >= 1 && newQuantity <= product.stock) {
      setQuantity(newQuantity);
    }
  };

  const handleShare = () => {
    toast({
      title: "🚧 هذه الميزة غير متوفرة حالياً—لكن لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀"
    });
  };

  const handleWishlist = () => {
    toast({
      title: "🚧 هذه الميزة غير متوفرة حالياً—لكن لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>{product.name} - Arganik Bio</title>
        <meta name="description" content={product.description} />
      </Helmet>

      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <motion.nav
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center space-x-2 space-x-reverse mb-8 text-sm arabic-text"
          >
            <Link to="/" className="text-gray-500 hover:text-amber-600">الرئيسية</Link>
            <ArrowRight className="w-4 h-4 text-gray-400" />
            <Link to="/products" className="text-gray-500 hover:text-amber-600">المنتجات</Link>
            <ArrowRight className="w-4 h-4 text-gray-400" />
            <span className="text-amber-600">{product.name}</span>
          </motion.nav>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-4"
            >
              <div className="aspect-square rounded-2xl overflow-hidden glass-effect">
                <img
                  src={product.images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {product.images.length > 1 && (
                <div className="grid grid-cols-4 gap-4">
                  {product.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`aspect-square rounded-lg overflow-hidden border-2 transition-all duration-300 ${
                        selectedImage === index 
                          ? 'border-amber-500 shadow-lg' 
                          : 'border-gray-200 hover:border-amber-300'
                      }`}
                    >
                      <img
                        src={image}
                        alt={`${product.name} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </motion.div>

            {/* Product Info */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-6"
            >
              <div>
                <h1 className="text-3xl font-bold arabic-text text-amber-800 mb-2">
                  {product.name}
                </h1>
                <div className="flex items-center space-x-2 space-x-reverse mb-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < product.rating 
                            ? 'text-yellow-400 fill-current' 
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-gray-600 arabic-text">
                    ({product.reviews} تقييم)
                  </span>
                </div>
              </div>

              <div className="price-tag text-2xl">
                {product.price} درهم
              </div>

              <p className="arabic-text text-gray-700 leading-relaxed text-lg">
                {product.description}
              </p>

              {/* Product Features */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold arabic-text text-amber-800">
                  مميزات المنتج:
                </h3>
                <ul className="space-y-2">
                  {product.features?.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2 space-x-reverse arabic-text text-gray-700">
                      <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Stock Status */}
              <div className="flex items-center space-x-2 space-x-reverse">
                <div className={`w-3 h-3 rounded-full ${
                  product.stock > 10 ? 'bg-green-500' : 
                  product.stock > 0 ? 'bg-yellow-500' : 'bg-red-500'
                }`}></div>
                <span className="arabic-text text-gray-700">
                  {product.stock > 10 ? 'متوفر' : 
                   product.stock > 0 ? `باقي ${product.stock} حبات` : 'غير متوفر'}
                </span>
              </div>

              {/* Quantity & Add to Cart */}
              <div className="space-y-4">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <span className="arabic-text font-medium text-gray-700">الكمية:</span>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <button
                      onClick={() => handleQuantityChange(-1)}
                      disabled={quantity <= 1}
                      className="w-10 h-10 rounded-full honey-gradient text-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-all duration-300"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <input
                      type="number"
                      value={quantity}
                      onChange={(e) => {
                        const value = parseInt(e.target.value);
                        if (value >= 1 && value <= product.stock) {
                          setQuantity(value);
                        }
                      }}
                      className="quantity-input w-16"
                      min="1"
                      max={product.stock}
                    />
                    <button
                      onClick={() => handleQuantityChange(1)}
                      disabled={quantity >= product.stock}
                      className="w-10 h-10 rounded-full honey-gradient text-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-all duration-300"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    onClick={handleAddToCart}
                    disabled={product.stock === 0}
                    className="btn-primary flex-1 text-lg py-3 arabic-text"
                  >
                    <ShoppingCart className="ml-2 h-5 w-5" />
                    أضف للسلة
                  </Button>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={handleWishlist}
                      variant="outline"
                      className="p-3 border-2 border-amber-600 text-amber-600 hover:bg-amber-50"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                    <Button
                      onClick={handleShare}
                      variant="outline"
                      className="p-3 border-2 border-amber-600 text-amber-600 hover:bg-amber-50"
                    >
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Product Info Tabs */}
              <div className="glass-effect rounded-2xl p-6 space-y-4">
                <h3 className="text-lg font-semibold arabic-text text-amber-800">
                  معلومات إضافية
                </h3>
                <div className="space-y-3 arabic-text text-gray-700">
                  <div className="flex justify-between">
                    <span>الوزن:</span>
                    <span>{product.weight || '500 جرام'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>المنشأ:</span>
                    <span>{product.origin || 'المغرب'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>تاريخ الإنتاج:</span>
                    <span>{product.productionDate || '2024'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>مدة الصلاحية:</span>
                    <span>{product.shelfLife || 'سنتان'}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetailPage;
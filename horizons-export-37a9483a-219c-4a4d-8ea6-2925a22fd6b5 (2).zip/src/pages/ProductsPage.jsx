import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Filter, Search } from 'lucide-react';
import ProductCard from '@/components/ProductCard';
import { useProducts } from '@/contexts/ProductContext';

const ProductsPage = () => {
  const { products } = useProducts();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState('all');

  const categories = [
    { value: 'all', label: 'جميع المنتجات' },
    { value: 'mountain', label: 'عسل جبلي' },
    { value: 'sidr', label: 'عسل سدر' },
    { value: 'wildflower', label: 'عسل الزهور البرية' },
    { value: 'acacia', label: 'عسل الأكاسيا' }
  ];

  const priceRanges = [
    { value: 'all', label: 'جميع الأسعار' },
    { value: '0-150', label: 'أقل من 150 درهم' },
    { value: '150-250', label: '150 - 250 درهم' },
    { value: '250-350', label: '250 - 350 درهم' },
    { value: '350+', label: 'أكثر من 350 درهم' }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    
    let matchesPrice = true;
    if (priceRange !== 'all') {
      const [min, max] = priceRange.split('-').map(p => p.replace('+', ''));
      if (max) {
        matchesPrice = product.price >= parseInt(min) && product.price <= parseInt(max);
      } else {
        matchesPrice = product.price >= parseInt(min);
      }
    }
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  return (
    <>
      <Helmet>
        <title>المنتجات - Arganik Bio</title>
        <meta name="description" content="تصفح مجموعة واسعة من منتجات العسل الطبيعي الأصيل في متجر أرجانيك بايو. عسل جبلي، عسل سدر، وأنواع مختلفة من العسل الطبيعي." />
      </Helmet>

      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl font-bold arabic-text text-amber-800 mb-4">
              منتجاتنا الطبيعية
            </h1>
            <p className="text-xl arabic-text text-gray-600 max-w-2xl mx-auto">
              اكتشف مجموعة واسعة من أجود أنواع العسل الطبيعي والمنتجات العضوية
            </p>
          </motion.div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="glass-effect rounded-2xl p-6 mb-8"
          >
            <div className="flex items-center mb-4">
              <Filter className="w-5 h-5 text-amber-600 ml-2" />
              <span className="text-lg font-semibold arabic-text text-amber-800">
                تصفية المنتجات
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Search */}
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="قلّب على المنتوجات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="form-input pr-10 arabic-text"
                />
              </div>

              {/* Category Filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="form-input arabic-text"
              >
                {categories.map(category => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>

              {/* Price Filter */}
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="form-input arabic-text"
              >
                {priceRanges.map(range => (
                  <option key={range.value} value={range.value}>
                    {range.label}
                  </option>
                ))}
              </select>
            </div>
          </motion.div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>

          {/* No Results */}
          {filteredProducts.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <div className="w-24 h-24 mx-auto mb-6 opacity-20">
                <Search className="w-full h-full text-gray-400" />
              </div>
              <h3 className="text-2xl font-semibold arabic-text text-gray-600 mb-2">
                ما لقيناش منتوجات مطابقة
              </h3>
              <p className="arabic-text text-gray-500">
                جرّب تبدل معايير البحث أو التصفية
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
};

export default ProductsPage;
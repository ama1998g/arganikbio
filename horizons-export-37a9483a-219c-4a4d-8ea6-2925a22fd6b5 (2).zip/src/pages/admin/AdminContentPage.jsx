import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useContent } from '@/contexts/ContentContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const AdminContentPage = () => {
  const { content, loading, updateContent } = useContent();
  const { toast } = useToast();
  const [formData, setFormData] = useState({});
  const [savingStates, setSavingStates] = useState({});

  useEffect(() => {
    if (!loading && content) {
      setFormData(content);
    }
  }, [content, loading]);

  const handleInputChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value,
      },
    }));
  };

  const handleSave = async (section) => {
    setSavingStates(prev => ({ ...prev, [section]: true }));
    const success = await updateContent(section, formData[section]);
    if (success) {
      toast({
        title: 'تم الحفظ بنجاح',
        description: `تم تحديث محتوى قسم "${section}".`,
      });
    }
    setSavingStates(prev => ({ ...prev, [section]: false }));
  };

  if (loading) {
    return <div className="flex justify-center items-center h-full p-6"><Loader2 className="h-8 w-8 animate-spin text-amber-500" /></div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-6 space-y-6"
    >
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-800">إدارة المحتوى</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قسم الهيرو (الصفحة الرئيسية)</CardTitle>
          <CardDescription>تعديل النصوص التي تظهر في أعلى الصفحة الرئيسية.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="hero-title">العنوان الرئيسي</Label>
            <Input id="hero-title" value={formData.hero?.title || ''} onChange={(e) => handleInputChange('hero', 'title', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="hero-subtitle">العنوان الفرعي</Label>
            <Input id="hero-subtitle" value={formData.hero?.subtitle || ''} onChange={(e) => handleInputChange('hero', 'subtitle', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="hero-button">نص الزر</Label>
            <Input id="hero-button" value={formData.hero?.button_text || ''} onChange={(e) => handleInputChange('hero', 'button_text', e.target.value)} />
          </div>
          <Button onClick={() => handleSave('hero')} disabled={savingStates['hero']} className="bg-amber-500 hover:bg-amber-600">
            {savingStates['hero'] ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
            حفظ قسم الهيرو
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>قسم "من نحن"</CardTitle>
          <CardDescription>تعديل محتوى صفحة "من نحن".</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="about-title">العنوان</Label>
            <Input id="about-title" value={formData.about_us?.title || ''} onChange={(e) => handleInputChange('about_us', 'title', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="about-p1">الفقرة الأولى</Label>
            <textarea id="about-p1" rows="4" className="w-full p-2 border rounded-md form-input" value={formData.about_us?.paragraph1 || ''} onChange={(e) => handleInputChange('about_us', 'paragraph1', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="about-p2">الفقرة الثانية</Label>
            <textarea id="about-p2" rows="4" className="w-full p-2 border rounded-md form-input" value={formData.about_us?.paragraph2 || ''} onChange={(e) => handleInputChange('about_us', 'paragraph2', e.target.value)} />
          </div>
          <Button onClick={() => handleSave('about_us')} disabled={savingStates['about_us']} className="bg-amber-500 hover:bg-amber-600">
            {savingStates['about_us'] ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
            حفظ قسم "من نحن"
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>معلومات التواصل</CardTitle>
          <CardDescription>تعديل معلومات التواصل التي تظهر في الموقع.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="contact-phone">رقم الهاتف</Label>
            <Input id="contact-phone" value={formData.contact_info?.phone || ''} onChange={(e) => handleInputChange('contact_info', 'phone', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="contact-email">البريد الإلكتروني</Label>
            <Input id="contact-email" type="email" value={formData.contact_info?.email || ''} onChange={(e) => handleInputChange('contact_info', 'email', e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="contact-address">العنوان</Label>
            <Input id="contact-address" value={formData.contact_info?.address || ''} onChange={(e) => handleInputChange('contact_info', 'address', e.target.value)} />
          </div>
          <Button onClick={() => handleSave('contact_info')} disabled={savingStates['contact_info']} className="bg-amber-500 hover:bg-amber-600">
            {savingStates['contact_info'] ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
            حفظ معلومات التواصل
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminContentPage;
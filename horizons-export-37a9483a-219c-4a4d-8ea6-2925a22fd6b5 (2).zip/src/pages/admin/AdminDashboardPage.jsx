import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Package, DollarSign, ShoppingCart } from 'lucide-react';
import { useProducts } from '@/contexts/ProductContext';
import { supabase } from '@/lib/supabaseClient';

const AdminDashboardPage = () => {
    const { products } = useProducts();
    const [stats, setStats] = useState({
        totalOrders: 0,
        totalRevenue: 0,
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('orders')
                .select('total_price');

            if (error) {
                console.error('Error fetching order stats:', error);
            } else {
                const totalRevenue = data.reduce((sum, order) => sum + (order.total_price || 0), 0);
                setStats({
                    totalOrders: data.length,
                    totalRevenue: totalRevenue,
                });
            }
            setLoading(false);
        };
        fetchStats();
    }, []);

    const displayStats = [
        {
            title: "إجمالي المنتجات",
            value: products.length,
            icon: Package,
            color: "bg-blue-500",
        },
        {
            title: "إجمالي الطلبات",
            value: loading ? "..." : stats.totalOrders,
            icon: ShoppingCart,
            color: "bg-green-500",
        },
        {
            title: "إجمالي الإيرادات",
            value: loading ? "..." : `${stats.totalRevenue.toLocaleString('ar-MA')} درهم`,
            icon: DollarSign,
            color: "bg-amber-500",
        },
    ];

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="p-6"
        >
            <h1 className="text-3xl font-bold mb-6 text-gray-800">لوحة التحكم</h1>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {displayStats.map((stat, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                        <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium text-gray-500">{stat.title}</CardTitle>
                                <div className={`p-2 rounded-full ${stat.color} text-white`}>
                                    <stat.icon className="h-5 w-5" />
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold text-gray-800">{stat.value}</div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>
            
            <div className="mt-8">
                <Card className="shadow-lg">
                    <CardHeader>
                        <CardTitle>مرحباً بك في لوحة تحكم Arganik Bio!</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-gray-600">
                           من هنا يمكنك إدارة منتجاتك وطلباتك بكل سهولة. استخدم القائمة الجانبية للتنقل بين الصفحات.
                        </p>
                    </CardContent>
                </Card>
            </div>
        </motion.div>
    );
};

export default AdminDashboardPage;
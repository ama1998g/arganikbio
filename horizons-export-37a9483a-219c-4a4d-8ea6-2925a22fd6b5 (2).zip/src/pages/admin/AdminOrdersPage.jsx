import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Eye, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const AdminOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchOrders = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching orders:', error);
      toast({
        title: 'خطأ في تحميل الطلبات',
        description: 'حدث خطأ أثناء جلب الطلبات.',
        variant: 'destructive',
      });
    } else {
      setOrders(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const getStatusVariant = (status) => {
    switch (status) {
      case 'تم التوصيل':
        return 'success';
      case 'قيد التجهيز':
        return 'warning';
      case 'ملغي':
        return 'destructive';
      default:
        return 'default';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-800">إدارة الطلبات</h1>
        <Button onClick={fetchOrders} variant="outline" size="sm" disabled={loading}>
            <RefreshCw className={`ml-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            تحديث
        </Button>
      </div>
      <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
                <Table>
                <TableHeader>
                    <TableRow>
                    <TableHead>الزبون</TableHead>
                    <TableHead>الهاتف</TableHead>
                    <TableHead>الإجمالي</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الإجراءات</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {loading ? (
                        <TableRow>
                            <TableCell colSpan="6" className="text-center py-10">
                            جاري تحميل الطلبات...
                            </TableCell>
                        </TableRow>
                    ) : orders.length > 0 ? (
                    orders.map((order) => (
                    <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.customer_name}</TableCell>
                        <TableCell style={{ direction: 'ltr' }} className="text-right">{order.customer_phone}</TableCell>
                        <TableCell>{order.total_price} درهم</TableCell>
                        <TableCell>
                        <Badge variant={getStatusVariant(order.status)}>{order.status}</Badge>
                        </TableCell>
                        <TableCell>{new Date(order.created_at).toLocaleDateString('ar-MA')}</TableCell>
                        <TableCell>
                        <Button variant="outline" size="icon" onClick={() => toast({ title: "ميزة عرض تفاصيل الطلب قيد التطوير", description: "🚧 هذه الميزة ليست مفعلة بعد. يمكنك طلبها في رسالتك القادمة! 🚀" })}>
                            <Eye className="h-4 w-4" />
                        </Button>
                        </TableCell>
                    </TableRow>
                    ))
                    ) : (
                        <TableRow>
                            <TableCell colSpan="6" className="text-center py-10 text-gray-500">
                                لا توجد أي طلبات حالياً.
                            </TableCell>
                        </TableRow>
                    )}
                </TableBody>
                </Table>
            </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminOrdersPage;
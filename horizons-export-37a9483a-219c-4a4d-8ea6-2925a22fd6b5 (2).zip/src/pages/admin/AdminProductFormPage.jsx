import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useProducts } from '@/contexts/ProductContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const AdminProductFormPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addProduct, updateProduct, getProductById } = useProducts();
  
  const isEditing = Boolean(id);
  const [product, setProduct] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop',
    images: ['https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=300&fit=crop'],
    category: 'general',
    rating: 4,
    reviews: 10,
  });

  useEffect(() => {
    if (isEditing) {
      const existingProduct = getProductById(id);
      if (existingProduct) {
        setProduct(existingProduct);
      }
    }
  }, [id, isEditing, getProductById]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const productData = {
      ...product,
      price: parseFloat(product.price),
      stock: parseInt(product.stock, 10),
      rating: parseFloat(product.rating || 4),
      reviews: parseInt(product.reviews || 10),
    };

    if (isEditing) {
      await updateProduct(productData);
    } else {
      const { id, ...newProductData } = productData;
      await addProduct(newProductData);
    }
    navigate('/admin/products');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-6"
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-gray-800">
            {isEditing ? 'تعديل المنتج' : 'إضافة منتج جديد'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">اسم المنتج</Label>
                <Input id="name" name="name" value={product.name} onChange={handleChange} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">السعر (درهم)</Label>
                <Input id="price" name="price" type="number" step="0.01" value={product.price} onChange={handleChange} required />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">الوصف</Label>
              <textarea
                id="description"
                name="description"
                value={product.description}
                onChange={handleChange}
                required
                rows="4"
                className="w-full p-2 border rounded-md form-input"
              ></textarea>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="stock">المخزون</Label>
                <Input id="stock" name="stock" type="number" value={product.stock} onChange={handleChange} required />
              </div>
               <div className="space-y-2">
                <Label htmlFor="image">رابط الصورة</Label>
                <Input id="image" name="image" value={product.image} onChange={handleChange} required />
              </div>
            </div>
            <div className="flex justify-end space-x-2 space-x-reverse">
              <Button type="button" variant="outline" onClick={() => navigate('/admin/products')}>
                إلغاء
              </Button>
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600">
                {isEditing ? 'حفظ التغييرات' : 'إضافة المنتج'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminProductFormPage;
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const AdminSettingsPage = () => {
  const { toast } = useToast();

  const handlePasswordChange = (e) => {
    e.preventDefault();
    toast({
      title: 'ميزة قيد التطوير',
      description: '🚧 إمكانية تغيير كلمة المرور ليست مفعلة بعد. يمكنك طلبها في رسالتك القادمة! 🚀',
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-6"
    >
      <h1 className="text-3xl font-bold mb-6 text-gray-800">الإعدادات</h1>
      <Card>
        <CardHeader>
          <CardTitle>تغيير كلمة المرور</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePasswordChange} className="space-y-4 max-w-md">
            <div className="space-y-2">
              <Label htmlFor="current-password">كلمة المرور الحالية</Label>
              <Input id="current-password" type="password" disabled placeholder="••••••••" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">كلمة المرور الجديدة</Label>
              <Input id="new-password" type="password" disabled placeholder="••••••••" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password">تأكيد كلمة المرور الجديدة</Label>
              <Input id="confirm-password" type="password" disabled placeholder="••••••••" />
            </div>
            <Button type="submit" className="bg-amber-500 hover:bg-amber-600">
              حفظ التغييرات
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminSettingsPage;